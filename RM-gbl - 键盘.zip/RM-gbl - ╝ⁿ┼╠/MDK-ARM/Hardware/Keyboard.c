#include "main.h"

int16_t Y_Pos;


void Key_Move_tuoluo(int w, int a, int s, int d)
{
	if(w && !a && !s&& !d)
	{
		chassis_move(0,1000,degreesToRadians(360));
	}
	if(!w && !a && s&& !d)
	{
		chassis_move(0,-1000,degreesToRadians(360));
	}
	if(!w && a && !s&& !d)
	{
		chassis_move(1000,0,degreesToRadians(360));
	}
	if(!w && !a && !s&& d)
	{
		chassis_move(-1000,0,degreesToRadians(360));
	}
	
	if(w && a && !s&& !d)
	{
		chassis_move(1000,1000,degreesToRadians(360));
	}
	if(w && !a && !s&& d)
	{
		chassis_move(-1000,1000,degreesToRadians(360));
	}
	
	if(!w && !a && s&& d)
	{
		chassis_move(-1000,-1000,degreesToRadians(360));
	}
	if(!w && a && s&& !d)
	{
		chassis_move(1000,-1000,degreesToRadians(360));
	}
	if(!w && !a && !s && !d)
	{
		chassis_move(0,0,degreesToRadians(360));
	}
}

void Key_Move_fast(int w, int a, int s, int d)
{
	if(w && !a && !s&& !d)
	{
		chassis_move(0,1100,degreesToRadians(0));
	}
	if(!w && !a && s&& !d)
	{
		chassis_move(0,-1100,degreesToRadians(0));
	}
	if(!w && a && !s&& !d)
	{
		chassis_move(1100,0,degreesToRadians(0));
	}
	if(!w && !a && !s&& d)
	{
		chassis_move(-1100,0,degreesToRadians(0));
	}
	
	if(w && a && !s&& !d)
	{
		chassis_move(1100,1100,degreesToRadians(0));
	}
	if(w && !a && !s&& d)
	{
		chassis_move(-1100,1100,degreesToRadians(0));
	}
	
	if(!w && !a && s&& d)
	{
		chassis_move(-1100,-1100,degreesToRadians(0));
	}
	if(!w && a && s&& !d)
	{
		chassis_move(1100,-1100,degreesToRadians(0));
	}
	if(!w && !a && !s && !d)
	{
		chassis_move(0,0,degreesToRadians(0));
	}
}

void Key_Move(int w, int a, int s, int d)
{
	if(w && !a && !s&& !d)
	{
		chassis_move(0,660,degreesToRadians(0));
	}
	if(!w && !a && s&& !d)
	{
		chassis_move(0,-660,degreesToRadians(0));
	}
	if(!w && a && !s&& !d)
	{
		chassis_move(660,0,degreesToRadians(0));
	}
	if(!w && !a && !s&& d)
	{
		chassis_move(-660,0,degreesToRadians(0));
	}
	
	if(w && a && !s&& !d)
	{
		chassis_move(660,660,degreesToRadians(0));
	}
	if(w && !a && !s&& d)
	{
		chassis_move(-660,660,degreesToRadians(0));
	}
	
	if(!w && !a && s&& d)
	{
		chassis_move(-660,-660,degreesToRadians(0));
	}
	if(!w && a && s&& !d)
	{
		chassis_move(660,-660,degreesToRadians(0));
	}
	if(!w && !a && !s && !d)
	{
		chassis_move(0,0,degreesToRadians(0));
	}
}

void Cal(void)
{
	Y_Pos+=rc.mouse.y*3;
	if(Y_Pos>32000)
	{
		Y_Pos = 32000;
	}
	if(Y_Pos<=-32000)
	{
		Y_Pos = -32000;
	}
}

void fire_tuoluo(void)
{
	if(rc.mouse.l==1)
	{
		mocalun_Run_Stop();
		VP_cmd_gimbal_booster(180+Y_Pos/32767.0*25.0, 37.7-rc.mouse.x/6.0,3900);
	}
	if(rc.mouse.l==0)
	{
		VP_cmd_gimbal_booster(180+Y_Pos/32767.0*25.0, 37.7-rc.mouse.x/6.0, 0);
		mocalun_Run_Stop();
	}
}

void fire(void)
{
	if(rc.mouse.l==1)
	{
		mocalun_Run_Stop();
		VP_cmd_gimbal_booster(180+Y_Pos/32767.0*25.0, -rc.mouse.x/6.0,3900);
	}
	if(rc.mouse.l==0)
	{
		VP_cmd_gimbal_booster(180+Y_Pos/32767.0*25.0, -rc.mouse.x/6.0, 0);
		mocalun_Run_Stop();
	}
}

void Task(void)
{
	Cal();
	if(rc.kb.bit.SHIFT==1)
	{
		Key_Move_tuoluo(rc.kb.bit.W, rc.kb.bit.A, rc.kb.bit.S, rc.kb.bit.D);
		fire_tuoluo();
	}
	if(rc.kb.bit.SHIFT==0&&rc.kb.bit.CTRL==0)
	{
		Key_Move(rc.kb.bit.W, rc.kb.bit.A, rc.kb.bit.S, rc.kb.bit.D);
		fire();
	}
	if(rc.kb.bit.SHIFT==0&&rc.kb.bit.CTRL==1)
	{
		Key_Move_fast(rc.kb.bit.W, rc.kb.bit.A, rc.kb.bit.S, rc.kb.bit.D);
		fire();
	}
}
