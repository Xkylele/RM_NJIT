#pragma once

extern int16_t Y_Pos;

void Key_Move_tuoluo(int w, int a, int s, int d);
void Key_Move(int w, int a, int s, int d);
void Key_Move_fast(int w, int a, int s, int d);
void fire(void);
void fire_tuoluo(void);
void Task(void);
