#pragma once

extern float Yaw;
extern float Yaw_start;
extern float Roll;
extern float Pitch;
void Gyro_Get(void);
void Gyro_Init(void);

