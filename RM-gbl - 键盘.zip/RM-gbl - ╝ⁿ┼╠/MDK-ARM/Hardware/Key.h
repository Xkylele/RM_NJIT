#ifndef __Key_H
#define __Key_H
uint8_t Key_GetNum(void);
#endif

