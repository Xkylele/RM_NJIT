#include "main.h"
#include "math.h"
// ����r 76 L 475
#define Radius_L 237
#define M_PI 3.14159265358979
#define R_wheel 0.076

float speed_cal[4];

double degreesToRadians(double degrees) {
    return degrees * (M_PI / 180.0);
}
double cal_length(void) {
    return (R_wheel * M_PI *2) ;
}


void chassis_move(float X, float Y, float target_omega)
{
    /********ֱ�Ӽ��㷽��********/
    //float speed_cal[4];
    float sin_ang = sin(degreesToRadians(Roll));
    float cos_ang = cos(degreesToRadians(Roll));
    float speed_X = X;
    float speed_Y = Y;

    speed_cal[0] = ((-cos_ang - sin_ang) * speed_X + (-sin_ang + cos_ang) * speed_Y + Radius_L * target_omega) / sqrt(2);
    speed_cal[1] = ((-cos_ang + sin_ang) * speed_X + (-sin_ang - cos_ang) * speed_Y + Radius_L * target_omega) / sqrt(2);
    speed_cal[2] = ((cos_ang + sin_ang) * speed_X + (sin_ang - cos_ang) * speed_Y + Radius_L * target_omega) / sqrt(2);
    speed_cal[3] = ((cos_ang - sin_ang) * speed_X + (sin_ang + cos_ang) * speed_Y + Radius_L * target_omega) / sqrt(2);
	V_cmd_chassis(speed_cal[0]/cal_length(),speed_cal[1]/cal_length(),speed_cal[2]/cal_length(),speed_cal[3]/cal_length());

}

void chassis_move_test(float target_speed, float target_dir, float target_omega)
{
    /********ֱ�Ӽ��㷽��********/
    //float speed_cal[4];
    float sin_ang = sin(0);
    float cos_ang = cos(0);
    float speed_X = target_speed * cos(target_dir);
    float speed_Y = target_speed * sin(target_dir);

    speed_cal[0] = ((-cos_ang - sin_ang) * speed_X + (-sin_ang + cos_ang) * speed_Y + Radius_L * target_omega) / sqrt(2);
    speed_cal[1] = ((-cos_ang + sin_ang) * speed_X + (-sin_ang - cos_ang) * speed_Y + Radius_L * target_omega) / sqrt(2);
    speed_cal[2] = ((cos_ang + sin_ang) * speed_X + (sin_ang - cos_ang) * speed_Y + Radius_L * target_omega) / sqrt(2);
    speed_cal[3] = ((cos_ang - sin_ang) * speed_X + (sin_ang + cos_ang) * speed_Y + Radius_L * target_omega) / sqrt(2);
	
		V_cmd_chassis(speed_cal[0],speed_cal[3],speed_cal[2],speed_cal[1]);
}


