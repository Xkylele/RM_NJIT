#include "main.h"

int flag_fire = 1;

void mocalun_init(void)
{
	HAL_TIM_Base_Start(&htim1);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_2);
	
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, 1000);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, 1000);
	
	HAL_Delay(3000);
}

void cmd_mocalun(int16_t spd)
{
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, spd);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, spd);
}
	
void stop_mocalun(void)
{
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, 1000);
	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, 1000);
}


void mocalun_Run_Stop(void)
{
	if(flag_fire==1&&rc.sw1==1)
	{
		cmd_mocalun(1200);
		VP_cmd_gimbal_booster(180-rc.ch1/660.0*25.0, 37.7-rc.ch0/660.0*9.0, 0);
		HAL_Delay(200);
		flag_fire=0;
	}
	if(flag_fire==0&&rc.sw1==3)
	{
		HAL_Delay(200);
		VP_cmd_gimbal_booster(180-rc.ch1/660.0*25.0, 37.7-rc.ch0/660.0*9.0, 0);
		stop_mocalun();
		flag_fire=1;
	}
		
}
