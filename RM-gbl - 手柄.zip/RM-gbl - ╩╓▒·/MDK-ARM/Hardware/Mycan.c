#include "main.h"

//motor_measure_t Ϊ �����Ϣ�ṹ��
//typedef struct
//{
//	uint16_t angle;
//	int16_t rpm;
//	int16_t dianliu;
//	uint8_t wendu;
//}motor_measure_t;
motor_measure_t motor_chassis[4];//��Ϊȫ�ֱ��� ��main��h������
motor_measure_t motor_gimbal[2];
motor_measure_t motor_booster;



void MyCAN_Init(void)
{
	CAN_FilterTypeDef CAN_FilterInitStructure;
	CAN_FilterInitStructure.FilterBank=0;//?????????????,????????13???
	CAN_FilterInitStructure.FilterScale=CAN_FILTERSCALE_32BIT;
	CAN_FilterInitStructure.FilterMode=CAN_FILTERMODE_IDMASK;
	CAN_FilterInitStructure.FilterFIFOAssignment=CAN_FILTER_FIFO0;
	CAN_FilterInitStructure.FilterIdHigh=0x0000;
	CAN_FilterInitStructure.FilterIdLow=0x0000;
	CAN_FilterInitStructure.FilterMaskIdHigh=0x0000;
	CAN_FilterInitStructure.FilterMaskIdLow=0x0000;
	CAN_FilterInitStructure.FilterActivation=CAN_FILTER_ENABLE;

	HAL_CAN_ConfigFilter(&hcan1, &CAN_FilterInitStructure);
}


//��can1�����ĸ�����ֵ
void CAN_cmd_chassis(int16_t m1,int16_t m2,int16_t m3,int16_t m4)
{
	uint32_t send_mail_box;
	uint8_t buff[8];
	CAN_TxHeaderTypeDef can_Tx;
	
	can_Tx.StdId = 0x200;
	can_Tx.IDE = CAN_ID_STD;
	can_Tx.RTR = CAN_RTR_DATA;
	can_Tx.DLC = 0x08;
	
	buff[0] = m1>>8;
	buff[1] = m1;
	buff[2] = m2>>8;
	buff[3] = m2;
	buff[4] = m3>>8;
	buff[5] = m3;
	buff[6] = m4>>8;
	buff[7] = m4;
	
	HAL_CAN_AddTxMessage(&hcan1,&can_Tx,buff,&send_mail_box);
}

void CAN_cmd_gimbal(int16_t m1,int16_t m2)
{
	uint32_t send_mail_box;
	uint8_t buff[4];
	CAN_TxHeaderTypeDef can_Tx;
	
	can_Tx.StdId = 0x1FF;
	can_Tx.IDE = CAN_ID_STD;
	can_Tx.RTR = CAN_RTR_DATA;
	can_Tx.DLC = 0x04;
	
	buff[0] = m1>>8;
	buff[1] = m1;
	buff[2] = m2>>8;
	buff[3] = m2;

	HAL_CAN_AddTxMessage(&hcan1,&can_Tx,buff,&send_mail_box);
}

 void CAN_cmd_gimbal_booster(int16_t m1,int16_t m2,int16_t m3)
{
	uint32_t send_mail_box;
	uint8_t buff[6];
	CAN_TxHeaderTypeDef can_Tx;
	
	can_Tx.StdId = 0x1FF;
	can_Tx.IDE = CAN_ID_STD;
	can_Tx.RTR = CAN_RTR_DATA;
	can_Tx.DLC = 0x06;
	
	buff[0] = m1>>8;
	buff[1] = m1;
	buff[2] = m2>>8;
	buff[3] = m2;
	buff[4] = m3>>8;
	buff[5] = m3 ;

	HAL_CAN_AddTxMessage(&hcan1,&can_Tx,buff,&send_mail_box);
}

/************************************************************************************************/
void jiesuan(motor_measure_t * motor, uint8_t * data)
{
	motor -> angle = (uint16_t)((data[0] << 8) | data[1]);
	motor -> rpm = (uint16_t)((data[2] << 8) | data[3]);
	motor -> dianliu = (uint16_t)((data[4] << 8) | data[5]);
	motor -> wendu = data[6];
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan1) 
{
	CAN_RxHeaderTypeDef Rxmessage;
	uint8_t Rx_data[8];

	HAL_CAN_GetRxMessage(hcan1, CAN_RX_FIFO0, &Rxmessage, Rx_data);
	
	int i=0;
	i = Rxmessage.StdId-0x201;
	
	if(i<4)
	{
		jiesuan(&motor_chassis[i],Rx_data);
	}
	else if(i==6)
	{
		jiesuan(&motor_booster,Rx_data);
	}
	else
	{
		jiesuan(&motor_gimbal[i-4],Rx_data);
	}
}

void V_cmd_gimbal(int16_t v1, int16_t v2)
{
	pid_gimbal_cal_v(v1,v2);
	CAN_cmd_gimbal(pid_gimbal[1].output, pid_gimbal[3].output);
}

void POS_cmd_gimbal(float angle1, float angle2, int16_t v)
{
	pid_gimbal_cal_pos(angle1,angle2);
	PID_Calc(&pid_booster,v,motor_booster.rpm);
	CAN_cmd_gimbal_booster(pid_gimbal[1].output, pid_gimbal[3].output,pid_booster.output);
}

void V_cmd_chassis(int16_t v1, int16_t v2, int16_t v3, int16_t v4)
{
	pid_chassis_cal_v(v1,v2,v3,v4);
	CAN_cmd_chassis(pid_chassis[0].output, pid_chassis[1].output, pid_chassis[2].output, pid_chassis[3].output);
}
void VP_cmd_gimbal_booster(float jiaodu, int16_t v1, int16_t v2)
{
	pid_gimbal_booster_cal(jiaodu,v1,v2);
	CAN_cmd_gimbal_booster(pid_gimbal[1].output, pid_gimbal[3].output,pid_booster.output);
}
