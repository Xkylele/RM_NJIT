#include "main.h"
#include "string.h"

robot_status_t Robo_state;
power_heat_data_t Robo_heat;

void Cp_jiesuan_202(power_heat_data_t * robo, uint8_t * data)
{
	robo -> buffer_energy = (uint16_t)((data[8] << 8) | data[9]);
	robo -> shooter_17mm_1_barrel_heat = (uint16_t)((data[10] << 8) | data[11]);
}

void Cp_jiesuan_201(robot_status_t * robo, uint8_t * data)
{
	robo -> robot_id = data[0];
	robo -> robot_level = data[1];
	robo -> shooter_barrel_heat_limit = (uint16_t)((data[8] << 8) | data[9]);
	robo -> chassis_power_limit = (uint16_t)((data[10] << 8) | data[11]);
}

void Cp_jiesuan(uint16_t id)
{
	if(id==0x201)
	{
		Cp_jiesuan_201(&Robo_state,rx_buffer_2+7);
	}
	if(id==0x202)
	{
		Cp_jiesuan_202(&Robo_heat,rx_buffer_2+7);
	}
	
}

void Cp_Get(void)
{
	if(recv_end_flag_2 == 1)  //������ɱ�־
	{
		if(rx_buffer_2[0]==0xA5)
		{
			uint16_t cmd_id = (uint16_t)((rx_buffer_2[5] << 8) | rx_buffer_2[6]);
			Cp_jiesuan(cmd_id);
		}
		memset(rx_buffer_2,0,rx_len_2);
		rx_len_2 = 0;//�������
		recv_end_flag_2 = 0;//������ս�����־λ
	}
	HAL_UART_Receive_DMA(&huart6,rx_buffer_2,BUFFER_SIZE_2);//���´�DMA����
}
