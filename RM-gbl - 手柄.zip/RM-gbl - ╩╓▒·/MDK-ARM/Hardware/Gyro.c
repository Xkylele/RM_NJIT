#include "main.h"
#include "string.h"
float Yaw;
int flag=0;
float Yaw_start;
float Roll;
float Pitch;


void Gyro_Init(void)
{
	if(recv_end_flag_1 == 1)  //������ɱ�־
	{
		if(rx_buffer_1[11]==0x55&&rx_buffer_1[12]==0x53)
		{
			short Yaw_t;
			Yaw_t = (short)((short)(rx_buffer_1[18] << 8) | rx_buffer_1[17]);
			Yaw_start  =Yaw_t/32768.0*180;
		}
		memset(rx_buffer_1,0,rx_len_1);
		rx_len_1 = 0;//�������
		recv_end_flag_1 = 0;//������ս�����־λ
	}
	HAL_UART_Receive_DMA(&huart1,rx_buffer_1,BUFFER_SIZE_1);//���´�DMA����
}


void Gyro_Get(void)
{
	if(recv_end_flag_1 == 1)  //������ɱ�־
	{
		if(rx_buffer_1[11]==0x55&&rx_buffer_1[12]==0x53&&!flag)
		{
			short Yaw_t;
			Yaw_t = (short)((short)(rx_buffer_1[18] << 8) | rx_buffer_1[17]);
			Yaw_start  =Yaw_t/32768.0*180;
			flag=1;
		}
		if(rx_buffer_1[11]==0x55&&rx_buffer_1[12]==0x53&&flag)
		{
			short Yaw_t;
			Yaw_t = (short)((short)(rx_buffer_1[18] << 8) | rx_buffer_1[17]);
			Yaw  =Yaw_t/32768.0*180;
			Yaw-=Yaw_start;
		}
		memset(rx_buffer_1,0,rx_len_1);
		rx_len_1 = 0;//�������
		recv_end_flag_1 = 0;//������ս�����־λ
	}
	HAL_UART_Receive_DMA(&huart1,rx_buffer_1,BUFFER_SIZE_1);//���´�DMA����
	Roll = motor_gimbal[1].angle*360.0/8191.0;//����ROLL ʵ����YAW ��̨6020�ĽǶ�
}


//			if(rx_buffer[0]==0x55&&rx_buffer[1]==0x53)
//			{
//				short Roll_t,Pitch_t,Yaw_t;
//				Roll_t = (short)((short)(rx_buffer[3] << 8) | rx_buffer[2]);
//				Pitch_t = (short)((short)(rx_buffer[5] << 8) | rx_buffer[4]);
//				Yaw_t = (short)((short)(rx_buffer[7] << 8) | rx_buffer[6]);
//				Roll  =Roll_t/32768.0*180;
//				Pitch  =Pitch_t/32768.0*180;
//				Yaw  =Yaw_t/32768.0*180;
//			}
