#pragma once

typedef struct 
{ 
 uint8_t robot_id; 
 uint8_t robot_level; 
 uint16_t current_HP; 
 uint16_t maximum_HP; 
 uint16_t shooter_barrel_cooling_value; 
 uint16_t shooter_barrel_heat_limit; 
 uint16_t chassis_power_limit; 
 uint8_t power_management_gimbal_output : 1; 
 uint8_t power_management_chassis_output : 1; 
 uint8_t power_management_shooter_output : 1; 
}robot_status_t;

typedef struct 
{
	uint16_t buffer_energy; 
  uint16_t shooter_17mm_1_barrel_heat; 
  uint16_t shooter_17mm_2_barrel_heat; 
  uint16_t shooter_42mm_barrel_heat; 
}power_heat_data_t;


extern robot_status_t Robo_state;
extern power_heat_data_t Robo_heat;


void Cp_Get(void);
void Cp_jiesuan_201(robot_status_t * robo, uint8_t * data);
void Cp_jiesuan_202(power_heat_data_t * robo, uint8_t * data);
void Cp_jiesuan(uint16_t id);

