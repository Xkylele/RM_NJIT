#pragma once

typedef struct
{
   	float kp, ki, kd; //����ϵ��
    float error, lastError; //���ϴ����
    float integral, maxIntegral; //���֡������޷�
    float output, maxOutput; //���������޷�
}PID;

extern PID pid_gimbal[4];// ID1:  λ�û� �ٶȻ� ID2�� λ�û� �ٶȻ�
extern PID pid_chassis[4];
extern PID pid_booster;

void PID_Calc(PID *pid, float reference, float feedback);
void PID_Calc_pos(PID *pid, float reference, float feedback);
void PID_Init(PID *pid, float p, float i, float d, float maxI, float maxOut);

void pid_gimbal_init(void);
void pid_gimbal_cal_pos(float target1, float target2);
void pid_gimbal_cal_v(int16_t target1, int16_t target2);


void pid_chassis_init(void);
void pid_chassis_cal_v(int16_t target1, int16_t target2, int16_t target3, int16_t target4);

void pid_booster_init(void);
void pid_gimbal_booster_cal(float jiaodu, int16_t v1, int16_t v2);


