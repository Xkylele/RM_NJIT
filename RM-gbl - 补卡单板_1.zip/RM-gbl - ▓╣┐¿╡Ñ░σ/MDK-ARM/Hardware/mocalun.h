#pragma once

extern int flag_fire;

void mocalun_init(void);
void cmd_mocalun(int16_t spd);
void stop_mocalun(void);
void mocalun_Run_Stop(void);
