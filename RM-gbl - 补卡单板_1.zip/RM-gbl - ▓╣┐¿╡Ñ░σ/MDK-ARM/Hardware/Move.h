#pragma once

extern float speed_cal[4];


double degreesToRadians(double degrees);
void chassis_move(float target_speed, float target_dir, float target_omega);
void chassis_move_test(float target_speed, float target_dir, float target_omega);
