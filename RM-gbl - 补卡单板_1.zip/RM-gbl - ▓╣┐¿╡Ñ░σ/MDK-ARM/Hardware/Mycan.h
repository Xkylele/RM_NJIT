#ifndef __Mycan_H
#define __Mycan_H

typedef struct
{
	uint16_t angle;
	int16_t rpm;
	int16_t dianliu;
	uint8_t wendu;
}motor_measure_t;

extern motor_measure_t motor_chassis[4];
extern motor_measure_t motor_gimbal[2];
extern motor_measure_t motor_booster;

void MyCAN_Init(void);

void CAN_cmd_chassis(int16_t m1,int16_t m2,int16_t m3,int16_t m4);
void CAN_cmd_gimbal(int16_t m1,int16_t m2);
void CAN_cmd_gimbal_booster(int16_t m1,int16_t m2,int16_t m3);

void jiesuan(motor_measure_t * motor, uint8_t * data);

void V_cmd_gimbal(int16_t v1, int16_t v2);
void POS_cmd_gimbal(float angle1, float angle2, int16_t v);

void V_cmd_chassis(int16_t v1, int16_t v2, int16_t v3, int16_t v4);

void VP_cmd_gimbal_booster(float jiaodu, int16_t v1, int16_t v2);

#endif

